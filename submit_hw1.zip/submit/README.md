## Introduction

The zip file contails two directories including the rob831 folder with the Python scripts and the runlogs fodler with sample logs from all the testing I performed, along with two files: a soft copy of the results report and this README file.

All trainings were carried out on Google Colab with the Jupyter File provided in the question. 
NOTE: The filepaths to the expert policy and expert data need to be provided in the full format, else it results in file not found errors.
eg: 
Policy File : '/content/hw_16831/16831_F23_HW/hw1/rob831/policies/experts/Ant.pkl'
Expert Data : '/content/hw_16831/16831_F23_HW/hw1/rob831/expert_data/expert_data_Ant-v2.pkl'

## Solving for Question 1 Part 2
Hyperparameters
ep len = 1000
num agent train steps per iter = 1000
batch size = 1000
eval batch size = 5000
train batch size = 100
max replay buffer size = 1000000
n layers = 2
size = 64
learning rate = 1e-3
seed = 5000

## Solving for Question 1 Part 3
Hyperparameters
ep len = 1000
num agent train steps per iter = 1000
batch size = 1000
eval batch size = 5000
train batch size = 100
max replay buffer size = 1000000
n layers = 2
size = 64
learning rate = 1e-3
seed = 5000

## Solving for Question 1 Part 4
Hyperparameters
ep len = 1000
batch size = 1000
eval batch size = 5000
train batch size = 100
max replay buffer size = 1000000
size = 64
seed = 5000

For the tuning the Learning Rate:
num agent train steps per iter = 1000
n layers = 2
learning rate = 1e-3 to 5e-3 in increments of 1e-3


For the tuning the number of layers:
num agent train steps per iter = 1000
learning rate = 5e-3
n layers = 2 to 5

For the tuning the number of layers:
num agent train steps per iter = 1000 to 2000 in increments of 250
learning rate = 5e-3
n layers = 2

## Solving for Question 2
ep len = 1000
num agent train steps per iter = 1000
batch size = 1000
eval batch size = 5000
train batch size = 100
max replay buffer size = 1000000
n layers = 2
size = 64
learning rate = 5e-3
seed = 5000

Remember to set No. of iterations to 10 and check mark the do_dagger parameter!






