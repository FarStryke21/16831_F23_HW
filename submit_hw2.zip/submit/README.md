## Introduction

The zip file contails two directories including the rob831 folder with the Python scripts and the runlogs fodler with sample logs from all the testing I performed, along with two files: a soft copy of the results report and this README file.

All trainings were carried out on Google Colab with the Jupyter File provided in the question

Configurations for individual tests are availble in the pdf file report for the homework. Any parameters not mentioned in the config were left at default values. Configurations are written in the form of commanfd line statements so that i could fit configurations for all experiments.